## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")
library(Roller)

## ------------------------------------------------------------------------
fair_coin <- device()
fair_coin


## ------------------------------------------------------------------------
weird_die <- device(
  sides = c('i', 'ii', 'iii', 'iv'),
  prob = rep(1/4, 4)
  )
weird_die

## ------------------------------------------------------------------------
# create a device called fair_die with sides, 1 to 6, each with a probability of 1/6
fair_die <- device(sides = 1:6, prob = rep(1/6, 6))
# roll fair_die 50 times
set.seed(123)
fair_50rolls <- roll(fair_die, times = 50)

# print the object
fair_50rolls

# to display the rolls vector with outputs of the rolls
fair_50rolls$rolls

# to display the sides vector with the sides of the `"device"` object
fair_50rolls$sides
  
# to display the prob vector with probabilities for each side of the `"device"` object
fair_50rolls$prob

# to display the total number of rolls
fair_50rolls$total

# to display what is in fair_50rolls
names(fair_50rolls)

## ------------------------------------------------------------------------
# creating a string die device
str_die <- device(
sides = c('a', 'b', 'c', 'd', 'e', 'f'),
prob = c(0.075, 0.1, 0.125, 0.15, 0.20, 0.35))
# roll str_die 20 times
set.seed(123)
str_rolls <- roll(str_die, times = 20)

# print the object
str_rolls

# to display the rolls vector with outputs of the rolls
str_rolls$rolls

# to display the sides vector with the sides of the `"device"` object
str_rolls$sides
  
# to display the prob vector with probabilities for each side of the `"device"` object
str_rolls$prob

# to display the total number of rolls
str_rolls$total


# to display what is in fair_50rolls
names(str_rolls)


## ------------------------------------------------------------------------
# creates the summary.rolls object for str_rolls
summary(str_rolls)

# to display the side column of the `device`
summary(str_rolls)$freq$side

# to display the count column of the `device`
summary(str_rolls)$freq$count

# to display the prop column of the `device`
summary(str_rolls)$freq$prop

# to display the names of the `summary.rolls` device, `str_rolls`
names(summary(str_rolls))

# to display the class of str_rolls
class(summary(str_rolls))

## ------------------------------------------------------------------------
# roll fair 8-sided die
set.seed(123)
fair_dev <- device(sides = letters[1:8], prob = rep(1/8, 8))
fair500 <- roll(fair_dev, times = 500)
# summary method
summary(fair500)

# extracting the roll in position 500
fair500[500]


## ------------------------------------------------------------------------
# replacing a roll in position 500
fair500[500] <- 'a'
fair500[500]


## ------------------------------------------------------------------------
# look at the new summary for fair 500
summary(fair500)

## ------------------------------------------------------------------------
# adding 100 rolls
fair600 <- fair500 + 100

# this is the summary of fair600
summary(fair600)

## ---- fig.show='hold', fig.width = 7, fig.height = 4, fair_50rolls-------
# plotting fair_50rolls using the plot method
plot(fair_50rolls)

## ---- fig.show='hold', fig.width = 7, fig.height = 4, fair500------------
# plotting fair500 using the plot method
plot(fair500, 500)

