library(testthat)
library(Roller)

test_check("Roller")
